# MAT-SI repository snapshot observed 2026-08-23

Repository: `ligereza/MAT-SI`
Default branch: `main`
Language: Python
Purpose in repository metadata: tools/automations for the MATH environment.

## Git state observed

- Current `main` HEAD observed through GitHub:  
  `059574fd6f5fbd28a3f62b705cfd702c243933ba`  
  message: `Revert "research: checkpoint autonomous operators foundation"`.
- Reverted commit `b24dcbb...` only introduced two `.claude/worktrees/...` gitlinks; the revert removes those accidental subproject entries.
- Important prior commit still represented in current tree:  
  `ebf8f6e978cf7a3ee99f6fc29981a245f11bf92f` — portability/replayability attack and baseline audit.
- `docs/STATE.md` still declares the accepted frontier as:  
  `c5860520c1f3873db2b32a2970b87ec9c809dfbc` — CODEINE v0 validated real-session frontier.

These are different concepts:
- **current Git HEAD** != **accepted frontier declared in STATE**.

A continuation agent must preserve that distinction.

## Repository architecture

Root:
- `corpus/`
- `docs/`
- `results/`
- `src/`
- `tests/`

Python packages:
- `src/matsi/`
- `src/codeine/`

Phase structure visible in README:
- Phase 1: competing kernel representations.
- Phase 2: self-reference/self-observation.
- Phase 3: distillation / structure discovery.
- Phase 3B/C/D: real slices, semantic falsification, evidence discovery.
- Phase 4: cross-domain transfer.
- Phase 4B: real experience transfer.
- Phase 4C: minimum observability.
- CODEINE v0: local checkpoint instrument.
- Phase 5: **not started**.

## Boundaries directly relevant to PiPi

### Phase 1 — representation comparison
Three candidate representations:
- `atom_pair`
- `content_dag`
- `rewrite_egraph`

`axis_experiments.py` already separates substrate and evaluator and builds Pareto frontiers across:
- description bytes;
- query time;
- evaluation time;
- structural sharing;
- fidelity.

This is directly compatible with an Order Profile / Lift Gain experiment.

### Phase 3 — G + residue
Phase 3 discovers a shared structure `G` plus per-object residue.
It requires:
- reconstruction;
- semantic agreement;
- compression;
- negative controls;
- held-out C;
- represented cross-surface normalization.

This is extremely close to PiPi's later `M + R` decomposition, but should be tested rather than declared identical.

### Phase 4C — minimum observability
Current minimum record:
- `before`
- opaque `intervention`
- `after`
- `provenance`

Optional `resources` remain separate measured dimensions.

This is already an appropriate evidence substrate for:
- lift attempts;
- future-equivalence tests;
- stop/fallback decisions;
- discovery cost.

### CODEINE v0
Current explicit persistence rule emits:
- `CONTINUE`
- `SWITCH`
- `STOP`
- `UNKNOWN`

It does not assert hidden success/progress/stuck semantics.

This is strongly compatible with PiPi-35's budgeted “no vale la pena” logic.

## Critical reproducibility correction on current main

`docs/reproducible-evidence.md` records a later audit that corrected an important Phase 4A comparison:
historical transfer gain `0.1667` compared different populations; corrected same-population gain is `0.0`, gate D.

Therefore:
- do not use the historical Phase 4 transfer result as established predictive-transfer evidence;
- preserve structural/behavioral observations separately from corrected predictive claims;
- use same-population baselines.

## Repository safety policy to preserve

From `docs/STATE.md`:
- `main` = accepted knowledge only;
- agents work on their own branches;
- no automatic merge/force-push to main;
- each branch states its parent commit;
- speculative work must not be treated as accepted evidence.

## Sources inspected

- `README.md`
- `docs/STATE.md`
- `docs/research.md`
- `docs/phase3-distillation.md`
- `docs/phase4-cross-domain.md`
- `docs/phase4c-minimum-observability.md`
- `docs/codeine-v0.md`
- `docs/reproducible-evidence.md`
- `src/matsi/axis_experiments.py`
- repository tree and recent commits through GitHub.
