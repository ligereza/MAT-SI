# Continuation prompt for a MAT-SI agent

You are continuing an external speculative research capsule called PiPi / “Dimensiones del Orden” in the context of `ligereza/MAT-SI`.

Read in this order:
1. `00_START_HERE/README_AGENT_HANDOFF.md`
2. `04_MAT_SI/MAT_SI_REPO_SNAPSHOT.md`
3. `01_CONTEXT/CONVERSATION_RECONSTRUCTION.md`
4. `02_MASTER/HYPOTHESIS_LEDGER.md`
5. `02_MASTER/EXPERIMENT_REGISTRY.md`
6. `04_MAT_SI/OPTIONAL_MAT_SI_INTEGRATION.md`

Rules:
- Treat every PiPi result as external/speculative until independently reproduced.
- Do not modify `main`.
- Do not start Phase 5.
- State parent commit on any branch.
- Do not resurrect killed numerology (`π` digit code, magic 3, magic 60/360) without a new preregistered falsifiable test.
- Do not call a transform a lift unless discovery + transform + solve cost is accounted.
- Preserve resource dimensions independently.
- Freeze hypotheses before held-out evaluation.
- Use matched baselines and negative controls.
- Preserve raw evidence/provenance.
- `UNKNOWN` is valid.
- If a result contradicts this capsule, keep the contradiction.

Primary objective:
Build a small **representation-lift audit** compatible with MAT-SI's existing evidence style. Test whether raw instances can be automatically mapped to lower-cost future-sufficient representations, with explicit no-lift controls.

First recommended benchmark:
A. raw Tseitin-like CNF → blind affine discovery → GF(2) solve (positive)
B. dense vs superincreasing subset-sum future quotient (positive + no-collapse)
C. π digit local-pattern search (negative control)

Report:
- baseline resources;
- discovery resources;
- transform resources;
- solve resources;
- reconstruction/fidelity;
- future sufficiency;
- state/width measures;
- evidence_for/evidence_against;
- fallback;
- final status.

Do not optimize for confirming the theory. Optimize for killing it cleanly if it is wrong.
