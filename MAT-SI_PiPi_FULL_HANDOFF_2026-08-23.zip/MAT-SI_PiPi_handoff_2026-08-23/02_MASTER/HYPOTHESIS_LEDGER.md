# Hypothesis ledger

## PROMOTE — core research directions

| Hypothesis | Why it survived | Main evidence |
|---|---|---|
| Many histories can share one future-sufficient state | Exact collapse in subset-sum dense families; adversarial no-collapse controls exist | 24, 25b |
| Representation can change search into algebra | Same Tseitin constraints: CNF search vs GF(2); lift inferred from raw CNF | 10C, 11 |
| Residue can contain further profitable structure | Recursive periodic residuals recovered; noise stopped | 22 |
| Discovery cost must be part of the score | Model-search overfit disappears after selection cost | 23 |
| Stop/fallback can operationalize “no vale la pena” | Budgeted portfolio bounds observed cost of wrong attempts | 35 |
| Effective width can dominate raw variable count | n fixed at 40 while separator width changed local exponential state | 41 |
| Structured quantum queries can expose global constraints | Simon collision-vs-linear-constraint scaling | 40 |
| Same mathematics can differ computationally by representation | Stable vs unstable polygon recurrence | 39b |

## KEEP — useful but not thesis-defining

- trajectory choice alters hitting times (6);
- finite-domain `D_order=3` witness (17), without universalizing 3;
- token/generator compression examples (19, 20);
- cardinality/baseline and cluster/lattice lifts (30–34);
- BBP direct access (36d);
- π geometry: `P6=3`, `π−3` residual (37–39).

## KILL / DO NOT REVIVE WITHOUT A NEW PREREGISTERED TEST

- π decimal digits contain an obvious hidden local code.
- `π−3` is a magical information-bearing decimal residual.
- 60 or 360 are π-specific anomalies.
- 3 is universally privileged.
- more dimensions automatically improve computation.
- a fixed-precision colita can encode arbitrarily much history.
- a universal practical master representation/solver can be found without paying discovery cost.
- parity/sign/small modulus is a universal future state.
- assistant behavior/refusal or aesthetic coherence is evidence.

## INVALID / BUGGED

- First random Taylor-pair closure synthesis in PiPi-17 used a truncating closure and produced a false positive. It must remain explicitly invalid.
