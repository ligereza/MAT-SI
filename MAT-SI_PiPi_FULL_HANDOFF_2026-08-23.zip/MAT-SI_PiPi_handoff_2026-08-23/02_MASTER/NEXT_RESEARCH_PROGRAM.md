# Next research program — PiPi 42+

## Priority A — Future-equivalence discovery

### PiPi-42: recover predictive states from raw trajectories
Use small processes with a known minimal state machine.

Protocol:
1. generate train trajectories without state labels;
2. expose only observation/action/history;
3. learn candidate equivalence classes of histories;
4. freeze classes;
5. test held-out future distributions/answers;
6. compare recovered state count and predictive loss to true minimal machine;
7. charge discovery cost.

Controls:
- process with true small state;
- process whose state grows with history;
- shuffled trajectories;
- label leakage test.

Goal:
make “colita = minimal future-relevant state” measurable rather than metaphorical.

## Priority A — Width discovery

### PiPi-43: representation/order width benchmark
Families:
- factor graphs / CSP;
- SAT;
- subset-sum;
- tensor-network-like graphs.

Compare:
- random elimination order;
- min-degree/min-fill;
- learned/heuristic separator search;
- baseline search.

Report:
- discovery time;
- induced width;
- peak local states;
- total solve cost;
- Lift Gain.

## Priority A — Meta-lift portfolio

Create a common interface:

`raw instance -> candidate transform -> certificate -> solver -> fallback`

Initial transforms/solvers:
- affine/GF(2);
- Horn;
- dual-Horn;
- 2-SAT;
- bounded-width elimination;
- subset-sum DP;
- MITM;
- cardinality/cluster/lattice decomposition;
- generic search.

The portfolio must report:
- attempted transforms;
- discovery costs;
- evidence for/against;
- held-out or exact correctness;
- fallback;
- regret vs oracle best after the fact.

## Priority B — Quantum bridge

### PiPi-44: noisy/generalized Simon
Vary:
- hidden subgroup dimension;
- measurement noise;
- incomplete constraints;
- query budget.

Measure when the linear lift stops paying.

### PiPi-45: toy order-finding cost ledger
Instrument:
- group size;
- order;
- number of phase samples;
- quantum-sampling proxy;
- classical postprocessing;
- success probability.

Compare brute/collision/order-based formulations.

### PiPi-46: multidimensional quantum tradeoff
Inspired by Regev-style factoring:
explicitly vary representation dimension against:
- circuit depth;
- repetitions;
- memory;
- postprocessing;
- total resource vector.

Do not collapse them prematurely to one scalar.

## Priority B — Tensor networks

### PiPi-47
Same qubit count / gate count, different connectivity and entanglement.

Measure:
- treewidth/contraction width;
- required bond dimension;
- memory;
- simulation time;
- approximation error.

Hypothesis:
effective width predicts effort better than raw qubit count.

## Mandatory ANTI-PI controls for every new experiment

- blind baseline;
- negative control;
- held-out data or exact proof;
- adversarial family;
- discovery-cost accounting;
- fallback/stop policy;
- provenance;
- explicit status: PROMOTE / KEEP / DEMOTE / KILL / INVALID.
