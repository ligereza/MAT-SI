# Prior-art map for the next agent

This file is a navigation aid, not a novelty claim.

## Closest theory to “minimal past that still changes future”
- Myhill–Nerode equivalence / minimal automata.
- Computational mechanics / causal states.
- Predictive State Representations.

## Closest theory to “model + colita”
- Minimum Description Length.
- sufficient statistics / predictive sufficiency.
- residual modeling.

## Closest theory to “search becomes algebra”
- Gaussian elimination over GF(2).
- algebraic CSP / polymorphisms.
- Schaefer dichotomy in Boolean CSP.
- hidden subgroup / Fourier methods in quantum algorithms.

## Closest theory to “dimension/order width”
- treewidth / pathwidth.
- variable elimination / junction tree.
- branchwidth / separators.
- tensor-network contraction width and bond dimension.

## Closest theory to “algorithm of algorithms”
- algorithm selection / portfolios (e.g. SATzilla-style ideas).
- hyper-heuristics / meta-solving.
- solver feature cost and fallback policies.

## Closest theory to “finite rule, huge expansion”
- grammar compression / straight-line programs.
- Kolmogorov complexity as an ideal but incomputable boundary.
- program/generator vs expanded output.

## Quantum controls
- Grover: unstructured search, quadratic optimal oracle gain.
- Simon: hidden XOR structure becomes linear constraints.
- Shor: order/period finding.
- Regev-style multidimensional factoring: useful warning that more dimensions can shift rather than remove cost.

## Novelty discipline

Do not claim the above are PiPi discoveries.

Possible original contribution, if demonstrated:
- a common experimental protocol that discovers representation + future quotient + solver while charging discovery cost;
- a benchmark of representation discovery across semantically equivalent surfaces;
- an operational `Lift Gain` / `Π-depth` with adversarial no-lift controls;
- a meta-solver that selects transform + state representation + solver + fallback, not only a solver.
