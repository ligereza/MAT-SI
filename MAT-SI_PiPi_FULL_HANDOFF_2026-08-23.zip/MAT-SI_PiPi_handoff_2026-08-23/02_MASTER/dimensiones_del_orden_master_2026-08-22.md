# DIMENSIONES DEL ORDEN — síntesis PiPi 1–41
Fecha: 2026-08-22

## 0. Veredicto ejecutivo

Después de 41 familias de experimentos, la hipótesis más fértil ya no es:

> π contiene un código oculto.

Ni tampoco:

> subir de dimensión siempre abarata el cálculo.

La versión que sobrevivió es más precisa:

> Un problema se vuelve más fácil cuando encontramos una representación en la que muchas historias distintas pasan a ser equivalentes respecto de las preguntas futuras que queremos responder.

La “colita” deja de ser un residuo decimal y pasa a ser:

> la información mínima del pasado que todavía puede cambiar el futuro.

Y Π deja de ser 3.14159... para convertirse provisionalmente en un **operador de representación**:

    Π : historia/estado bruto -> (estructura explicativa, estado residual suficiente)

La Dimensión del Orden no debería ser una sola dimensión geométrica. Es mejor tratarla como un **perfil de recursos** de la representación encontrada.

---

# 1. Qué murió

## 1.1 π decimal como código local oculto

PiPi-36:
- 100,000 dígitos de π contra e, sqrt(2), azar uniforme, PRNG y π barajado.
- Markov, módulos de posición, dependencias temporales, compresión y 206 modelos candidatos.
- Resultado para π: ningún predictor local sobrevivió fuera de muestra.
- Markov elegido: orden 0.
- módulo elegido bajo MDL: 1.
- contra 100 secuencias aleatorias, π cayó en percentiles ordinarios.

Conclusión:
- No hay evidencia en nuestros detectores de un “código local” útil dentro de 141592...
- La búsqueda numerológica debe permanecer muerta salvo que aparezca una hipótesis predictiva nueva y pre-registrable.

## 1.2 60 y 360 como números especiales de π

PiPi-38/39:
- La cola geométrica de polígonos regulares inscritos cumple

    R_n = π - n sin(π/n)
    R_n ~ π^3 / (6 n^2)

- El ajuste dio exponente ≈ 1.999997.
- 60 y 360 no son anomalías una vez removida la ley 1/n².
- 6 sí tiene una razón exacta: con diámetro 1, el hexágono inscrito tiene perímetro 3.

Conclusión:
- 6: estructura geométrica real.
- 60/360: importantes histórica y geométricamente, pero no “códigos” numéricos de π en nuestros datos.

## 1.3 “La colita pequeña contiene información infinita gratis”

PiPi-18:
- una cola a precisión fija tiene un número finito de estados;
- las colisiones son inevitables al crecer la historia;
- los casi-retornos de π reprodujeron aproximaciones racionales conocidas como 355/113.

Conclusión:
- una colita puede ser un estado útil;
- no puede contener información ilimitada a precisión fija.

## 1.4 “Más dimensiones siempre ayudan”

PiPi-7/8/8b:
- aparentes ventajas 3D desaparecieron al permitir todas las relaciones 2D;
- mejor 2D ganó 54/54;
- 3D/4D estaban empaquetando varias relaciones binarias, no aportando estructura irreducible.

Conclusión:
- dimensión adicional debe demostrar información irreducible o menor costo total.

## 1.5 “Existe un buscador universal práctico de la mejor representación”

PiPi-19–23 + teoría:
- la representación mínima depende del lenguaje;
- la complejidad de Kolmogorov ideal es incomputable;
- probar muchos modelos crea falsas mejoras si no se cobra el costo de búsqueda.

Conclusión:
- Π debe ser **relativo a un lenguaje de hipótesis y un presupuesto**.
- no puede ser una operación universal omnisciente.

---

# 2. Qué sobrevivió

## 2.1 Equivalencia por futuro

PiPi-24:
en subset-sum, una historia completa de decisiones puede colapsar a

    (i, remaining)

si dos historias llegan al mismo par, sus futuros son idénticos.

Instancia densa n=22:
- árbol bruto: 8,388,607 nodos
- estados memoizados suficientes: 1,614
- reducción: >5,000x

Instancia supercreciente:
- 8,388,607 -> 8,388,607
- ninguna compresión.

Principio:

    ORDEN = muchas historias distintas comparten el mismo futuro.

Este principio tiene análogos formales directos:
- Myhill–Nerode en autómatas;
- causal states en computational mechanics;
- predictive state representations.

## 2.2 La colita como estado suficiente

Definición provisional:

    R(h) = información mínima de la historia h necesaria para responder una clase de consultas futuras Q.

Exactamente:

    h1 ~_Q h2
    iff
    para toda consulta futura q en Q,
    Answer(q | h1) = Answer(q | h2)

La colita es la clase de equivalencia o una coordenada que la identifica.

Versión aproximada:
permitir error <= epsilon.

## 2.3 El ancho importa más que el tamaño bruto

PiPi-41:
seis problemas gráficos con exactamente n=40 variables.

Anchura inducida min-fill:
- path: 1
- cycle: 2
- ladder: 2
- grid 5x8: 5
- clique10+path: 9
- random sparse: 10

En eliminación binaria, el mayor factor local tiene:

    2^width

estados.

Mismo n=40:
- width 1 -> 2 estados locales
- width 10 -> 1024 estados locales

Principio:

    el costo puede depender del tamaño del “corte” pasado/futuro,
    no del número total de variables.

Conexiones:
- treewidth / pathwidth;
- variable elimination;
- junction trees;
- tensor-network contraction.

## 2.4 La representación puede convertir búsqueda en álgebra

PiPi-10C:
mismas restricciones Tseitin:
- CNF + DPLL simple: crecimiento explosivo;
- sistema GF(2) + eliminación gaussiana: crecimiento pequeño.

A 45 variables:
- GF(2): ~0.106 ms
- DPLL simple: ~5339 ms

El factor exacto no debe sobreinterpretarse porque el DPLL era deliberadamente sencillo.
El resultado conceptual sí es fuerte:

    misma instancia semántica,
    diferente representación,
    diferente clase práctica de esfuerzo.

PiPi-11:
la estructura affine fue detectada automáticamente desde CNF crudo.
Controles perturbados/random no fueron falsamente clasificados.

Esto es uno de los resultados internos más fuertes.

## 2.5 El residuo puede tener estructura recursiva

PiPi-21/22:
se construyeron residuos con períodos 17, 113, 251.

El sistema encontró:

    R0 -> periodo 17 -> R1
       -> periodo 113 -> R2
       -> periodo 251 -> R3

Con ruido aleatorio:
- no inventó capas rentables.

Principio:

    aplicar Π nuevamente solo tiene sentido si el residuo todavía admite una reducción que paga su propio costo.

## 2.6 “No vale la pena” puede formalizarse

Definir costo de una capa:

    C_layer =
        C_discovery
      + C_representation
      + C_solve_after_lift

Ganancia:

    Delta =
        C_before - C_layer

Continuar solo si:

    Delta > 0

PiPi-35 implementó un portfolio con abandono:
- probar una representación;
- si consume el presupuesto del fallback sin cerrar, abortar;
- ejecutar método seguro.

Peor regret observado ~2.48x en la suite.
No es universal, pero demuestra que “equivocarse con costo acotado” es una estrategia operativa.

---

# 3. Pi como unidad: definición que sí sobrevive

## 3.1 No usar π como constante numérica

La idea útil no es reemplazar 1 por 3.14159.

Usar Π como nombre de una operación semántica:

    Π_{L,B,Q}(R)

donde:
- L = lenguaje de representaciones permitido;
- B = presupuesto de descubrimiento;
- Q = clase de consultas futuras;
- R = estado/residuo actual.

Salida:

    (M, R')

tal que:
- M explica/estructura parte de R;
- R' conserva la información necesaria para Q;
- costo total mejora respecto de seguir con R bruto.

No buscamos el óptimo universal: buscamos el mejor lift encontrado dentro de L y B.

## 3.2 Π-depth

Definir profundidad Π:

    K_Π = número de capas sucesivas con Delta_i > 0

No significa “dimensión física”.
Mide cuántas veces fue rentable convertir residuo en estructura.

## 3.3 PiPi-39 como ejemplo literal de “veces”

Desde el dato exacto del hexágono:

    (n, P_n) = (6, 3)

una recurrencia estable que no contiene π en el update produce:

    P_6 -> P_12 -> P_24 -> ...

y converge a π.

La cola:

    R_k = π - P_{6*2^k}

cae aproximadamente por factor 1/4 en cada doubling.

Esto no es un nuevo algoritmo para π; es la geometría clásica de polígonos.
Pero sirve como ejemplo limpio:

    “una vez” = aplicar una transformación al error restante,
    no sumar una unidad.

---

# 4. La Dimensión del Orden no debería ser un escalar único

Intentar forzar todo a “D=2,3,4” produjo falsos positivos.

Propuesta: usar un ORDER PROFILE.

## 4.1 S — predictive-state complexity

Cuántos bits/estados hacen falta para identificar el futuro relevante.

Ejemplo:
- Myhill–Nerode: log2 del número de clases de equivalencia;
- causal states: entropía de estados causales;
- PSR: dimensión/rango de la representación predictiva.

## 4.2 W — separator width

Máxima información que debe cruzar una descomposición.

Ejemplos:
- treewidth;
- pathwidth;
- factor scope en variable elimination;
- contraction width en tensor networks.

## 4.3 A — algebraic certificate complexity

Qué estructura algebraica hay que detectar para cambiar de solver.

Ejemplos PiPi:
- XOR / affine -> GF(2)
- bijunctive -> 2-SAT
- Horn -> Horn propagation
- dual-Horn -> dual-Horn
- polymorphisms / CSP identities.

## 4.4 Q — query complexity

Cuántas interacciones con la función/oráculo se necesitan para recuperar el orden.

Este eje se vuelve crítico al comparar clásico y quantum.

## 4.5 L — lift/discovery cost

Costo de descubrir la representación.

Regla ANTI-PI:

    ninguna reducción cuenta si escondió el costo original en la construcción del lift.

---

# 5. Puente con teoría conocida: no reinventar

## 5.1 Myhill–Nerode

Dos historias son equivalentes si ninguna continuación futura puede distinguirlas respecto de aceptación.
El número de clases es el tamaño del DFA mínimo.

Nuestra “colita suficiente” es conceptualmente muy cercana a esta idea.

## 5.2 Computational Mechanics

Los causal states agrupan pasados que inducen la misma distribución de futuros.
La representación causal es mínima para predicción.

Esto es probablemente el pariente teórico más cercano a:

    “la información mínima del pasado que todavía cambia el futuro”.

## 5.3 Predictive State Representations

Representan estado mediante predicciones observables sobre futuros posibles, en vez de variables latentes arbitrarias.

Muy útil para transformar nuestra intuición en experimentos de aprendizaje de estado.

## 5.4 Treewidth / variable elimination

Formaliza que la complejidad de muchos problemas depende del ancho de la interfaz que debe mantenerse al separar el problema.

PiPi-41 es una versión toy de este principio.

## 5.5 Algebraic CSP / polymorphisms

La tractabilidad de CSP finito está ligada a estructura algebraica/polymorphisms.
PiPi-12–16 estaba redescubriendo un borde conocido en el caso Booleano.

La contribución potencial no está en volver a demostrar Schaefer/Bulatov/Zhuk:
está en **descubrir automáticamente la representación/certificado y contabilizar el costo del descubrimiento**.

## 5.6 MDL / Kolmogorov / Levin search

MDL:
- una regularidad cuenta si comprime incluyendo el costo del modelo.

Kolmogorov:
- la descripción mínima ideal existe conceptualmente, pero no es computable en general.

Levin search:
- existe universalidad teórica pagando fuertemente por longitud del programa y tiempo.

Esto limita cualquier interpretación mágica de Π.

## 5.7 Algorithm selection

SATzilla, AutoFolio y la literatura de algorithm selection ya formalizan:
- extraer features baratas;
- elegir solver por instancia;
- considerar costo de features y generalización.

PiPi-27–35 debe compararse contra esta literatura.
Nuestro ángulo distintivo debería ser:
- seleccionar no solo solver,
- sino **transformación/representación + solver + regla de abandono**.

---

# 6. Quantum: la prueba de estrés más fértil

## 6.1 Grover como control negativo

Búsqueda no estructurada de N elementos:

    clásico: Theta(N)
    quantum: Theta(sqrt(N))

Grover es óptimo en el modelo oracle.

Interpretación Dimensiones del Orden:

- el oráculo no expone una estructura comprimible adicional;
- quantum puede reorganizar amplitudes;
- pero no convierte el problema en un sistema pequeño de relaciones;
- resultado: ganancia cuadrática, no colapso exponencial.

Esto es un excelente ANTI-PI:
quantum no significa “todas las posibilidades gratis”.

## 6.2 Simon como control positivo

Problema:
existe s != 0 tal que

    f(x) = f(x xor s)

Clásicamente:
hay que esperar una colisión;
complejidad ~ 2^(n/2).

Quantum:
cada ejecución produce un vector y que satisface

    y · s = 0 mod 2

Después de ~n restricciones lineales, s se obtiene por álgebra GF(2).

PiPi-40 simuló esta diferencia.

n=26:
- dominio: 67,108,864
- mediana clásica: 9,526 queries
- mediana quantum idealizada: 26 queries
- ratio: ~366x

Ajuste:
- clásico: log2 queries ≈ 0.4964 n + constante
- quantum: lineal en n.

Este resultado reproduce la estructura teórica esperada:
la diferencia no es “probar todos a la vez”;
es que la medición en la representación Fourier/Hadamard devuelve **restricciones globales sobre el secreto**.

Esto es exactamente una forma de “Order Lift”.

## 6.3 Shor

Shor reduce factoring a order/period finding.
Quantum phase estimation + QFT hacen visible la periodicidad como información de fase.
El factoring ideal queda en tiempo polinómico en el número de bits.

Lectura PiPi:

    espacio de intentos
        ->
    función periódica escondida
        ->
    cambio de base / phase sampling
        ->
    pocas muestras estructuradas
        ->
    postprocesamiento clásico.

Es mucho más cercano a “Dimensión del Orden” que Grover.

## 6.4 Regev: la prueba ANTI-PI perfecta

Regev propuso una variante multidimensional de factoring:
- circuitos de ~O(n^(3/2)) gates;
- ejecutados ~sqrt(n) veces;
- postprocesamiento clásico de lattice.

La mejora mueve el equilibrio:
- más dimensiones / lattice sampling;
- circuitos individuales menores;
- más repeticiones;
- mayor costo clásico y espacial.

Lección:

    subir de dimensión puede reducir una parte del costo
    y aumentar otra.

Por eso nuestra métrica debe ser costo total, no “dimensión” sola.

## 6.5 Hardware actual

La teoría de Shor no implica que hoy pueda romperse RSA-2048.

Un resource estimate clásico de Gidney–Ekerå (2021) estimó, bajo supuestos concretos, unos 20 millones de noisy qubits y ~8 horas para RSA-2048.

En 2026 IBM reportó experimentos de ventaja sobre circuitos lógicos específicos y mantiene una hoja de ruta hacia sistemas fault-tolerant más grandes.
Eso es progreso real, pero está muy lejos de identificar “quantum = factoring práctico inmediato”.

---

# 7. Tensor networks: probablemente el puente más fértil con “Dimensión”

Un estado de n qubits tiene, en representación densa:

    2^n amplitudes.

Pero ciertos estados admiten una Matrix Product State / tensor network compacta si la estructura de correlación lo permite.

El costo ya no depende solamente de n:
depende de cantidades como
- bond dimension chi;
- Schmidt rank;
- contraction width / treewidth;
- estructura geométrica del circuito.

Esto encaja extremadamente bien con nuestra investigación:

    expansión gigantesca
    !=
    descripción mínima necesaria.

Pero también da el control negativo:
si chi crece exponencialmente, la representación tensorial pierde la ventaja.

Ruta experimental:
- mismos n qubits;
- misma profundidad;
- variar conectividad/entanglement;
- medir bond dimension necesaria y costo de simulación;
- comparar contra treewidth del circuito.

PiPi-41 ya da la versión puramente clásica del mismo principio.

---

# 8. Una formalización operativa nueva para el proyecto

## 8.1 Order Quotient

Para problema P y consultas Q:

    h1 ~_Q h2

si sus futuros son indistinguibles para Q.

El quotient H / ~_Q es el espacio de estados relevantes.

## 8.2 Order Width

Para una descomposición del problema:

    W = máximo tamaño/costo del estado que debe cruzar un corte.

No contar variables totales.
Contar interfaz necesaria.

## 8.3 Lift Gain

    G =
        C_baseline
        /
        (C_discovery + C_transform + C_solve)

Un lift solo “existe operacionalmente” si G > 1.

## 8.4 Π-depth

Aplicar recursivamente:

    R_i --Π--> (M_i, R_{i+1})

mientras:

    Delta_i > 0

La profundidad K_Π es descriptiva de la instancia y del lenguaje de hipótesis, no una constante universal.

## 8.5 Order Profile

En vez de un D único:

    O(P,Q,L,B) = (S, W, A, Qc, Lc, K)

donde:
- S = predictive-state complexity
- W = separator width
- A = algebraic certificate complexity
- Qc = query complexity
- Lc = lift discovery cost
- K = profitable Π-depth

Este vector puede compararse entre representaciones.

---

# 9. Ranking de caminos por fertilidad

## TIER A — continuar inmediatamente

### A1. Future-equivalence discovery
Objetivo:
aprender automáticamente el quotient mínimo o aproximado de historias por futuro.

Bases teóricas:
- Myhill–Nerode
- causal states
- PSR

Experimento PiPi-42:
- procesos con estado mínimo conocido;
- dar solo trayectorias crudas;
- recuperar clases predictivas;
- medir costo de descubrimiento, predicción y número de estados.

Criterio de éxito:
encontrar menor estado predictivo sin leakage y con held-out future.

### A2. Width discovery
Objetivo:
que Π descubra automáticamente separadores/tree decompositions útiles.

PiPi-43:
- SAT/CSP/factor graphs/tensor networks;
- comparar min-fill, exact/approx treewidth, random order, learned ordering;
- cobrar costo de encontrar la descomposición.

Criterio:
C_discover + C_solve(width) < baseline.

### A3. Representation + solver portfolio
Flagship.

Biblioteca inicial:
- GF(2)
- Horn
- dual-Horn
- 2-SAT
- treewidth DP
- subset-sum DP
- MITM
- cluster/lattice decomposition
- generic DPLL/search

Entrada:
raw instance.

Salida:
- transformation
- solver
- confidence
- predicted cost
- fallback
- actual regret.

Esto une PiPi-11, 15, 27–35.

---

# 10. TIER B — quantum bridge

## B1. Simon generalized
PiPi-40 debe extenderse:
- hidden subgroup dimension k;
- ruido en mediciones;
- ecuaciones parciales;
- classical collision vs quantum Fourier samples;
- threshold donde la ventaja desaparece.

Pregunta:
cuánta estructura global debe exponer una query para reducir un espacio exponencial a un sistema lineal.

## B2. Shor / order finding toy
No volver a “factorizar números”.
Instrumentar:
- tamaño del grupo;
- order r;
- número de phase samples;
- costo QFT/QPE;
- costo classical continued fractions;
- probabilidad de éxito.

Comparar:
- brute/collision;
- classical order algorithms;
- ideal quantum samples.

## B3. Regev-style multidimensional tradeoff
Modelar explícitamente:

    dimension d
    vs
    circuit depth
    vs
    repetitions
    vs
    classical lattice cost
    vs
    memory/noise

Este es un test directo de:
“más dimensión” no significa “menos esfuerzo total”.

---

# 11. TIER B — tensor-network bridge

PiPi-44:
- generar circuitos con mismo número de qubits y gates;
- variar geometría y entanglement;
- simular como state vector y MPS/TTN;
- medir bond dimension máxima;
- estimar treewidth/contraction width;
- relacionar costo real con estas medidas.

Hipótesis:
el predictor de esfuerzo más fuerte será un “ancho efectivo” de la representación, no n.

Control:
familias con alto entanglement pero estructura simulable, para evitar convertir bond dimension en nuevo número mágico.

---

# 12. TIER C — Pi numérico

Mantener solo como laboratorio pedagógico y de falsificación.

Útil:
- BBP como ejemplo de random access desde generador compacto;
- polígonos como ejemplo de recurrencia y error residual;
- estabilidad numérica como ejemplo de representaciones algebraicamente equivalentes con costos distintos.

No priorizar:
- mensajes en dígitos;
- numerología 3/6/60/360;
- patrones no pre-registrados.

---

# 13. La tesis de trabajo más fuerte

Versión corta:

> La dificultad computacional observada depende menos del tamaño bruto del espacio que de la mínima interfaz de información que debe conservarse para distinguir futuros relevantes, más el costo de descubrir una representación que exponga esa interfaz.

Π es el operador experimental que intenta encontrar esa representación.

“Dimensión del Orden” es el perfil de tamaño/ancho/costo de la interfaz resultante.

---

# 14. Predicciones falsables

La idea empieza a ser científica solo si produce predicciones.

P1.
Para familias con n similar pero treewidth diferente, costo de eliminación correlacionará mejor con width que con n.

Ya apoyado por PiPi-41.

P2.
Si dos historias son future-equivalent, reemplazarlas por una sola clase no cambiará respuestas a Q.

Ya apoyado por PiPi-24.

P3.
Si un lift solo reparametriza sin reducir estado suficiente/ancho, no producirá ganancia neta después de cobrar descubrimiento.

Apoyado por PiPi-8b y 23.

P4.
Problemas oracle sin estructura aprovechable mostrarán, en quantum, como máximo mejoras tipo Grover dentro de ese modelo; hidden algebraic structure puede permitir saltos mucho mayores.

Apoyado conceptualmente por Grover vs Simon/Shor.

P5.
Más dimensiones mejorarán una métrica local pero pueden empeorar costo total por samples, memory o postprocessing.

A probar con Regev-style toy.

P6.
Un meta-solver que cobra features/discovery y usa fallback puede tener regret acotado y superar single-best solver en una distribución mixta.

A probar a escala seria.

---

# 15. Qué sería realmente nuevo

NO sería nuevo:
- causal states;
- Myhill–Nerode;
- treewidth;
- polymorphisms;
- MDL;
- solver portfolios;
- hidden subgroup / QFT;
- tensor-network bond dimension.

Posible espacio original:

1. Una capa común y operacional que trate todos esos casos como:
   future quotient + representation lift + discovery cost + stop rule.

2. Un benchmark de “representation discovery”:
   mismo problema semántico presentado bajo lenguajes diferentes.

3. Una métrica de **Lift Gain** y **Π-depth** evaluada empíricamente.

4. Un meta-solver que no solo elige algoritmo:
   elige transformación + estado suficiente + solver + presupuesto de abandono.

5. Un corpus adversarial diseñado explícitamente para detectar cuándo el costo se escondió en el lift.

Ese sería un programa de investigación defendible.


# Referencias de research usadas para orientar esta síntesis

- Shalizi & Crutchfield, “Computational Mechanics: Pattern and Prediction, Structure and Simplicity”, Journal of Statistical Physics (2001).
  https://link.springer.com/article/10.1023/A%3A1010388907793

- Littman, Sutton & Singh, “Predictive Representations of State”, NeurIPS 2001.
  https://papers.nips.cc/paper/1983-predictive-representations-of-state

- Childs & van Dam, “Quantum algorithms for algebraic problems”, Reviews of Modern Physics 82 (2010).
  https://link.aps.org/doi/10.1103/RevModPhys.82.1

- Shor, “Polynomial-Time Algorithms for Prime Factorization and Discrete Logarithms on a Quantum Computer”.
  https://arxiv.org/abs/quant-ph/9508027

- IBM Quantum Learning, Simon’s algorithm.
  https://quantum.cloud.ibm.com/learning/courses/fundamentals-of-quantum-algorithms/quantum-query-algorithms/simon-algorithm

- Zalka, “Grover's quantum searching algorithm is optimal”.
  https://arxiv.org/abs/quant-ph/9711070

- Regev, “An Efficient Quantum Factoring Algorithm”.
  https://arxiv.org/abs/2308.06572

- Pilatte, “Unconditional correctness of recent quantum algorithms for factoring and computing discrete logarithms”.
  https://arxiv.org/abs/2404.16450

- Gidney & Ekerå, “How to factor 2048 bit RSA integers in 8 hours using 20 million noisy qubits”, Quantum 5, 433 (2021).
  https://quantum-journal.org/papers/q-2021-04-15-433/

- Dumitrescu et al., “Benchmarking treewidth as a practical component of tensor-network–based quantum simulation”.
  https://pmc.ncbi.nlm.nih.gov/articles/PMC6298732/

- Schollwöck, “The density-matrix renormalization group in the age of matrix product states”.
  https://arxiv.org/abs/1008.3477

- Barron, Rissanen & Yu, “The Minimum Description Length Principle in Coding and Modeling”.
  https://web.mit.edu/6.433/www/handouts/minimumdescriptionlength.pdf

- Vitányi, “How incomputable is Kolmogorov complexity?”
  https://arxiv.org/abs/2002.07674

- SATzilla / portfolio-based algorithm selection.
  https://www.jair.org/index.php/jair/article/view/10556

- IBM Quantum roadmap, current 2026 milestones.
  https://www.ibm.com/roadmaps/quantum/
