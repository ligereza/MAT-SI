# PiPi-36 — π digits under the conceptual Π operator

## Question

Test the old fiction that π's digit sequence contains a hidden code, but under the newer conceptual framing:

- Π is not the number 3.14159...
- Π is an operation that tries to replace expanded history with a smaller future-sufficient rule.
- A candidate structure only survives if it generalizes out of sample and beats controls.
- Discovery cost and multiple testing must be paid.

## Experiment A — local statistical/predictive structure

Sequences:
- π
- e
- sqrt(2)
- uniform random decimal digits
- PRNG decimal digits
- shuffled π

100,000 decimal digits each.
Split: 60k train / 20k validation / 20k test.

Models:
- unigram
- Markov orders 1..5
- index modulo m
- lag mutual information
- generic zlib compression

Result:
- π selected Markov order 0.
- π selected index modulus 1 under MDL.
- Test cross-entropy for π was ~3.32199 bits/digit, essentially log2(10).
- No tested local predictor beat the uniform-like baseline out of sample.
- e, sqrt(2), PRNG and shuffled π behaved similarly.

Interpretation:
No evidence of a locally predictive "hidden code" in the tested decimal representation.

## Experiment B — empirical null and calibration

π was compared against 100 independent random decimal sequences.

π percentiles in the null:
- Markov-1 gain: 79th percentile
- best index-modulus gain: 51st percentile
- maximum lag mutual information (lags 1..20): 80th percentile
- mean lag mutual information: 45th percentile

These are ordinary values, not anomalies.

Calibration:
- planted lag-17 structure was detected as lag 17 and generalized to held-out future.
- planted modulus-17 structure was detected as modulus 17.
- therefore the negative result for π is not simply because the detector is blind.

## Experiment C — pattern casino

Allowed 206 candidate models to compete:
- 64 lag models
- 127 position-modulus models
- combined previous-digit + position models
- unigram baseline

Selection was made on validation data, then frozen and evaluated on unseen test data.

For π:
- raw validation winner: unigram
- MDL winner: unigram
- held-out gain over unigram: 0

For planted lag-17:
- winner: lag 17
- held-out gain: ~0.0501 bits/digit

For planted modulus-23:
- raw validation winner: modulus 23
- held-out gain: ~0.00686 bits/digit

Thus the search apparatus can recover deliberately hidden simple structure, while π did not expose one in this model family.

## Experiment D — generator-level order / BBP

The negative local result does NOT mean π lacks finite generative structure.

The BBP formula allows direct extraction of hexadecimal digits of π without computing all preceding digits.

Direct BBP extraction was implemented and independently checked against sequential hexadecimal expansion at positions:

0, 1, 2, 3, 10, 50, 100, 500, 1000, 5000

All 10 matched exactly.

This is a qualitatively different kind of order:

local digit prediction:
    history -> next digit

versus generator-level access:
    (rule, position n) -> digit at n

The second can bypass explicit traversal of previous digits.

## What died

1. Simple hidden decimal correlations in π, under the tested model family.
2. Position parity/modulus as an obvious secret state.
3. Short-lag temporal recurrence as a useful predictor.
4. Pattern mining without held-out prediction.
5. Treating statistical randomness-like behavior as evidence of no underlying rule.

## What survived

The strongest surviving distinction is:

    observable sequence != generative description

π can look statistically random locally while still having a short mathematical specification.

Under the conceptual Π framing:

    expanded history  ->  generative rule + query coordinate

This suggests that the important "colita" may not be a residual digit pattern. It may be the minimal coordinate required by a compact generator to answer a future query.

A provisional form is:

    Π(x, n) = (M, r_n)

where:
- M is a finite generative rule/model,
- n is the requested position/state,
- r_n is only the residual information not already forced by M.

## Anti-PI warning

This is not unique to π.

e, sqrt(2), many computable constants, and seeded PRNG sequences also have compact generators.

So the next meaningful question is not:

    "Does π have a finite rule?"

It does.

The harder question is:

    "What class of future queries can be answered from a compact rule without traversing the expanded history, and at what computational cost?"

That question is falsifiable and connects directly to minimum effort, hidden state, direct access, and representation lift.
