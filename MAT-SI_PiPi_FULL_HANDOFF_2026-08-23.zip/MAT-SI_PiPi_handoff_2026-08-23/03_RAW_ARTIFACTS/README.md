# Raw artifacts

This directory contains every PiPi-prefixed file that still existed in `/mnt/data` when the capsule was built. Filenames are preserved exactly. Some early experiment scripts were no longer present; their methods/results are reconstructed in `02_MASTER/EXPERIMENT_REGISTRY.md` and `01_CONTEXT/CONVERSATION_RECONSTRUCTION.md` rather than fabricated.
