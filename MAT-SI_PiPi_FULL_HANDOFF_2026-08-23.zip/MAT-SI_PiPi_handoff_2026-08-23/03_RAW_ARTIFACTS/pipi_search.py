#!/usr/bin/env python3
"""
PiPi Search
Explorador evolutivo de proyecciones de dos loops ocultos.

Idea:
- Un estado interno tiene dos winding numbers coprimos (m, n).
- Normalizamos un loop global a u in [0, 1).
- Cada proyeccion produce una sola "sombra" observable.
- Medimos cuantas parejas (m, n) diferentes producen la misma sombra.
- Las proyecciones que conservan mas identidad sobreviven.

Esto NO es un algoritmo de factorizacion RSA. Es un banco de pruebas
para estudiar identifiabilidad, fase, winding y "colitas".
"""

from __future__ import annotations

import argparse
import math
from collections import defaultdict
from dataclasses import dataclass
from typing import Callable

import numpy as np


Array = np.ndarray


@dataclass(frozen=True)
class Candidate:
    name: str
    fn: Callable[[Array, Array], Array]


CANDIDATES = [
    Candidate("phase_sum_mod", lambda a, b: (a + b) % 1.0),
    Candidate("phase_diff_mod", lambda a, b: (a - b) % 1.0),
    Candidate("abs_phase_diff", lambda a, b: np.abs(a - b)),
    Candidate("phase_product", lambda a, b: a * b),
    Candidate("phase_min", lambda a, b: np.minimum(a, b)),
    Candidate("phase_max", lambda a, b: np.maximum(a, b)),
    Candidate("phase_sum", lambda a, b: a + b),
    Candidate(
        "cos_sum",
        lambda a, b: np.cos(2 * np.pi * a) + np.cos(2 * np.pi * b),
    ),
    Candidate(
        "cos_product",
        lambda a, b: np.cos(2 * np.pi * a) * np.cos(2 * np.pi * b),
    ),
    Candidate(
        "phase_relation_cos",
        lambda a, b: np.cos(2 * np.pi * (a - b)),
    ),
    Candidate(
        "circular_distance",
        lambda a, b: np.minimum((a - b) % 1.0, (b - a) % 1.0),
    ),
    Candidate(
        "same_half",
        lambda a, b: ((a < 0.5) == (b < 0.5)).astype(float),
    ),
]


def hidden_pairs(max_winding: int) -> list[tuple[int, int]]:
    """Parejas no ordenadas coprimas."""
    return [
        (m, n)
        for m in range(1, max_winding + 1)
        for n in range(m, max_winding + 1)
        if math.gcd(m, n) == 1
    ]


def trace(
    m: int,
    n: int,
    candidate: Candidate,
    samples: int,
) -> Array:
    """
    Un loop global completo.
    m y n dicen cuantas vueltas internas ocurren dentro de ese loop.
    """
    u = np.arange(samples, dtype=float) / samples
    phase_a = (m * u) % 1.0
    phase_b = (n * u) % 1.0
    return candidate.fn(phase_a, phase_b)


def signature(y: Array, decimals: int = 8) -> bytes:
    """Firma determinista de la sombra observada."""
    return np.round(np.asarray(y, dtype=float), decimals).tobytes()


def score_candidate(
    candidate: Candidate,
    pairs: list[tuple[int, int]],
    samples: int,
) -> dict:
    groups: dict[bytes, list[tuple[int, int]]] = defaultdict(list)

    for m, n in pairs:
        sig = signature(trace(m, n, candidate, samples))
        groups[sig].append((m, n))

    collisions = [g for g in groups.values() if len(g) > 1]

    return {
        "name": candidate.name,
        "pairs": len(pairs),
        "unique_signatures": len(groups),
        "identifiability": len(groups) / len(pairs),
        "collision_groups": len(collisions),
        "worst_collision": max((len(g) for g in groups.values()), default=0),
        "examples": collisions[:3],
    }


def run(max_winding: int, samples: int) -> list[dict]:
    pairs = hidden_pairs(max_winding)
    results = [
        score_candidate(candidate, pairs, samples)
        for candidate in CANDIDATES
    ]
    return sorted(
        results,
        key=lambda r: (
            r["identifiability"],
            -r["worst_collision"],
            -r["collision_groups"],
        ),
        reverse=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-winding", type=int, default=25)
    parser.add_argument("--samples", type=int, default=32)
    args = parser.parse_args()

    results = run(args.max_winding, args.samples)

    print(
        f"PiPi search | max_winding={args.max_winding} "
        f"| samples={args.samples}"
    )
    print()
    print(
        f"{'projection':24} {'unique':>9} {'total':>7} "
        f"{'score':>8} {'worst':>7}"
    )
    print("-" * 62)

    for r in results:
        print(
            f"{r['name']:24} "
            f"{r['unique_signatures']:9d} "
            f"{r['pairs']:7d} "
            f"{r['identifiability']:8.3f} "
            f"{r['worst_collision']:7d}"
        )

    print("\nCollision examples for weak projections:")
    for r in results:
        if r["examples"]:
            print(f"- {r['name']}: {r['examples']}")


if __name__ == "__main__":
    main()
