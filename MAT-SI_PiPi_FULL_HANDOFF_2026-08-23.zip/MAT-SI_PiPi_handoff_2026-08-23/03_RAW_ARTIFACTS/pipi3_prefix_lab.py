#!/usr/bin/env python3
from __future__ import annotations
import math
import numpy as np
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import GroupKFold, cross_val_score

def primes_upto(n):
    out=[]
    for x in range(2,n+1):
        if all(x%d for d in range(2,int(x**0.5)+1)):
            out.append(x)
    return out

def order(a,n):
    if math.gcd(a,n)!=1: return None
    x=1
    for k in range(1,2*n+1):
        x=(x*a)%n
        if x==1: return k
    return None

def raw_prefix(N,a,L=32):
    vals=[]
    x=1
    for _ in range(L):
        vals.append(x/N)
        x=(x*a)%N
    return np.asarray(vals,float)

def features_from_prefix(vals,N,a,L):
    v=vals[:L]
    d=np.diff(v, prepend=v[0])
    return np.r_[
        math.log(N), math.log(a), a/N,
        v.mean(), v.std(), v.min(), v.max(),
        np.mean(np.abs(d)),
        v, d
    ]

def build(prime_limit=43, base_limit=15, maxL=32):
    ps=primes_upto(prime_limit)
    records=[]
    for i,p in enumerate(ps):
        for q in ps[i+1:]:
            N=p*q
            for a in range(2,min(base_limit,N-1)+1):
                if math.gcd(a,N)!=1: continue
                r=order(a,N); rp=order(a%p,p); rq=order(a%q,q)
                if not (r and rp and rq): continue
                m,n=sorted((r//rp,r//rq))
                vals=raw_prefix(N,a,maxL)
                labels={ell:int((m%ell==0) ^ (n%ell==0)) for ell in (2,3,5,7)}
                records.append((N,a,vals,labels,(m,n)))
    return records

def auc_for(records,L,ell):
    X=np.vstack([features_from_prefix(v,N,a,L) for N,a,v,lab,hid in records])
    y=np.asarray([lab[ell] for N,a,v,lab,hid in records])
    groups=np.asarray([N for N,a,v,lab,hid in records])
    if len(np.unique(y))<2: return float("nan"), y.mean()
    clf=ExtraTreesClassifier(
        n_estimators=80,max_depth=6,min_samples_leaf=6,
        class_weight="balanced",random_state=0,n_jobs=-1
    )
    cv=GroupKFold(n_splits=3)
    auc=float(np.mean(cross_val_score(clf,X,y,groups=groups,cv=cv,scoring="roc_auc",n_jobs=1)))
    return auc,y.mean()

def main():
    records=build()
    print("PiPi-3 | prefix-only public orbit")
    print(f"samples={len(records)} | semiprimes={len(set(r[0] for r in records))}")
    print("Features see only N, a, and first L residues; no period r, no factors, no gcd probes.\n")
    for L in (4,8,16,32):
        print(f"L={L}")
        for ell in (2,3,5,7):
            auc,pos=auc_for(records,L,ell)
            print(f"  pi/{ell}: positive={pos:.3f}  AUC={auc:.3f}")
        print()

if __name__=="__main__":
    main()
