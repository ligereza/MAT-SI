# START HERE — MAT-SI / PiPi handoff

## Purpose

This capsule transfers the complete **research state** of the PiPi / “Dimensiones del Orden” conversation into a form an agent working on `ligereza/MAT-SI` can continue without reading the original chat.

It contains:

- a chronological reconstruction of the conceptual conversation;
- the full experiment registry from PiPi-1 through PiPi-41;
- every PiPi CSV / Python / Markdown artifact still present in the session filesystem;
- a hypothesis ledger marking what is alive, dead, invalid, or only pedagogical;
- a current snapshot of MAT-SI as inspected through GitHub;
- an **optional** integration proposal that does not declare Phase 5;
- a continuation prompt for another agent;
- SHA-256 manifests.

### Important limitation

`CONVERSATION_RECONSTRUCTION.md` is a **semantic reconstruction**, not a verbatim ChatGPT transcript export. It was built from the conversation state, preserved research summaries, visible turns, and generated artifacts. Where an original script no longer existed in the session filesystem, the experiment method/result is preserved in the registry rather than pretending the exact source survived.

## Current strongest thesis

The strongest surviving version is:

> **Observed computational difficulty depends strongly on the smallest future-relevant interface/state a representation must preserve, plus the cost of discovering that representation.**

Provisional vocabulary:

- **Π** — representation-lift attempt, not the numeric constant 3.14159.
- **colita / residue** — information not captured by the current model; in the strongest version, the minimal past information still capable of changing relevant futures.
- **future quotient** — histories grouped when future queries cannot distinguish them.
- **Order Profile** — a vector of predictive-state size, separator width, algebraic certificate cost, query complexity, discovery cost, and profitable Π-depth.
- **ANTI-PI** — every apparent gain must ask: *where was the cost hidden?*

## Reading order

1. `../04_MAT_SI/MAT_SI_REPO_SNAPSHOT.md`
2. `../01_CONTEXT/CONVERSATION_RECONSTRUCTION.md`
3. `../02_MASTER/HYPOTHESIS_LEDGER.md`
4. `../02_MASTER/EXPERIMENT_REGISTRY.md`
5. `../02_MASTER/NEXT_RESEARCH_PROGRAM.md`
6. Optional: `../04_MAT_SI/OPTIONAL_MAT_SI_INTEGRATION.md`
7. Then inspect `../03_RAW_ARTIFACTS/`.

## Non-negotiable epistemic rules

1. Do not revive killed hypotheses because they are aesthetically appealing.
2. Do not treat speculation as accepted MAT-SI evidence.
3. Never claim a lift is cheap without counting discovery/transform cost.
4. Freeze hypotheses before held-out evaluation.
5. Use negative/adversarial controls.
6. Keep raw evidence and derived interpretation separate.
7. Do not collapse independent resource dimensions into one cost unless the experiment explicitly defines and justifies that aggregation.
8. A new dimension must prove irreducible information or lower total cost; dimension count alone is not evidence.
9. If the candidate representation fails, preserve the failure.
10. Do not start MAT-SI Phase 5 automatically.

## High-value positive results

- PiPi-10C / 11: same constraints become cheap algebra after an automatically discoverable GF(2) lift.
- PiPi-22: structured residue can be recursively distilled until no profitable layer remains.
- PiPi-24: millions of decision histories can collapse to a tiny future-sufficient state space — but not on adversarial families.
- PiPi-34: cluster-local compression plus complement closure beat generic search on a structured subset-sum family.
- PiPi-35: wrong representation attempts can be abandoned under an explicit fallback budget.
- PiPi-40: Simon is a clean quantum example of search/collision being replaced by global linear constraints.
- PiPi-41: with total variable count held fixed, elimination effort follows separator width.

## High-value negative results

- π decimal hidden-code search: no signal in tested local model family.
- 3 is not universally special.
- 60/360 are not π anomalies in polygon-tail experiments.
- more dimensions do not automatically help.
- a fixed-precision residual cannot encode unlimited history.
- a universal practical representation oracle is not available.
- coarse residual projections (parity/sign/mod small m) generally destroy future distinctions.

